const jimp = require("jimp")

exports.run = async (client, message, args, ops) => {

        let img = jimp.read("https://cdn.discordapp.com/attachments/715342600340504590/747301984251412570/20200822_081155.png")
        if(!args[0]) 
return message.channel.send(`Escreva alguma coisa!`)
if(!args[1]) 
return message.channel.send(`Escreva outra coisa!`)
if(args.join(" ").length > 30) return message.channel.send(`Use no maximo 30 caracteres!`)
        img.then(image => {
            jimp.loadFont(jimp.FONT_SANS_32_BLACK).then(font => {
                image.resize(463, 426)
                image.print(font, 252, 65, args.join(' '), 450)
                image.print(font, 252, 270, args.slice(1).join(" "), 450)
                image.getBuffer(jimp.MIME_PNG, (err, i) => {
                    message.channel.send({files: [{ attachment: i, name: "drake.png"}]})
                })
            })
        })
    }