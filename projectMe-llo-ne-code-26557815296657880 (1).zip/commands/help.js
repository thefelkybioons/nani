const { MessageEmbed } = require("discord.js")
const fs = require('fs');
const length = fs.readdirSync('./commands').length;

module.exports.run = async (client, message, args, ops) => {

message.delete()
const help = new MessageEmbed()
.setAuthor(`Painel de Ajuda` , `https://cdn.discordapp.com/attachments/741379232516800564/747172773230542950/Disk.gif`)
.setColor("#009df3") //a cor que você quiser aqui 
.setTitle("")
.setDescription(`**Olá, Seja bem vindo a minha Central de Ajuda!**`)
.addField('🗂Comandos:', [ `<:numb_1:763297394740953118>**│**Moderação \n<:numb_2:763297274998554635>**│**Utilitários \n<:numb_3:763297116775907348>**│**Diversão \n<:numb_4:763296993329545227>  | Música \n<:numb_5:763293502834475028>  | Configuração`])
.addField('🔗Meus Links:', [ `💎**[Me adicione](https://discordapp.com/oauth2/authorize?client_id=734819851889016902&scope=bot&permissions=4656329)**\n💎**[Vote em mim](https://botsparadiscord.com/bots/734819851889016902)**\n💎**[Servidor de Suporte](https://discord.gg/PrsAtP3)**`])
.setImage(`https://cdn.discordapp.com/attachments/707636623545860106/763710369586741248/20201008_073002.jpg`)
.setThumbnail(`https://cdn.discordapp.com/attachments/707636623545860106/715053830332743700/PicsArt_05-27-01.06.52.png`)
.setFooter(`Pág. 0-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()

message.reply(help)
 .then(msg => {
msg.react("763297394740953118")//seria pro de diversao
msg.react("763297274998554635")//seria pro de economia
msg.react("763297116775907348")//Puxar a reação do primeiro emoji com o coletor e responder em outra aba
msg.react("763296993329545227")
msg.react("763293502834475028")//da aba de muderação
msg.react("738115656125382837")//esse primeiro vai ser a flecha de voltar
let cfiltro = (react, user) => react.emoji.name === "numb_1" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let ccoletor = msg.createReactionCollector(cfiltro, {time: 500000})
ccoletor.on('collect', bm => {
bm.users.remove(message.author.id)
const adm = new MessageEmbed()
.setAuthor(`| Comandos - Moderação` , `https://cdn.discordapp.com/attachments/715998928390324347/737835112174977115/1595983242134.png`)
.setColor("#009df3")// da sua preferência
.setTitle("")
.setDescription(`\n\n<:ss3ta:738141028682432652>**kick** - Expulsa um membro do seu Servidor: m.kick <@user> <motivo>\n<:ss3ta:738141028682432652>**ban** - Da um ban em um membro do seu Servidor: m.ban <@user> <motivo>\n<:ss3ta:738141028682432652>**unban** - Tira o ban de um usuário banido do Servidor: m.unban <id-do-usuário-banido>\n<:ss3ta:738141028682432652>**tempmute** - Silencia um usuário do seu Servidor: m.mute <@user> <tempo> <motivo>\n<:ss3ta:738141028682432652>**lock/unlock** - Tranca ou Destranca um chat: m.lock/m.unlock\n<:ss3ta:738141028682432652>**slowmode** - Muda o tempo do modo lento do chat: m.slownmode <número-de-segundos>\n<:ss3ta:738141028682432652>**clear** - Limpa mensagens do chat: m.clear <número de mensagens para serem apagadas> (No max. 99)\n<:ss3ta:738141028682432652>**say** - Fazer Eu falar alguma coisa: m.say <frase>\n<:ss3ta:738141028682432652>**dm** - faz o bot mandar uma mensagem na dm do usuário mencionado: m.dm <@user> <frase>\n<:ss3ta:738141028682432652>**warn** - Manda um warn (aviso) na DM do usuário mencionado: m.warn <@user> <aviso>\n<:ss3ta:738141028682432652>**Votação** - Cria uma Votação no Servidor: m.votação <frase-para-votação>\n<:ss3ta:738141028682432652>**Sorteio(Beta)** - Cria um Sorteio no Servidor: m.sorteio <tempo> <chat-do-sorteio> <prêmio>`)
.setFooter(`Pág. 1-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(adm)
})

let dfiltro = (react, user) => react.emoji.name === "numb_2" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let dcoletor = msg.createReactionCollector(dfiltro, {time: 500000})
dcoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const adm = new MessageEmbed()
.setAuthor(`| Comandos - Utilitários` , `https://cdn.discordapp.com/attachments/715998928390324347/737835112409858129/1595983278165.png`)
.setColor("#009df3")// da sua preferência
.setTitle("")
.setDescription(`\n\n<:ss3ta:738141028682432652>**help** - Meu Painel de ajuda: m.help\n<:ss3ta:738141028682432652>**ping** - Mostra meu ping atual: m.ping\n<:ss3ta:738141028682432652>**uptime** - Mostra o tempo que estou acordada: m.uptime\n<:ss3ta:738141028682432652>**serverinfo** - Mostra informações do Servidor: m.serverinfo\n<:ss3ta:738141028682432652>**userinfo** - Mostra informações do usuário mencionado: m.userinfo <@user>\n<:ss3ta:738141028682432652>**botinfo** - Mostra mais informações sobre mim: m.botinfo\n<:ss3ta:738141028682432652>**wikis(Em Breve)** - Criar uma wiki no Servidor: m.wikis <comando>\n<:ss3ta:738141028682432652>**cpu** - Mostra o uso do meu CPU e Memória RAM: m.cpu`)
.setFooter(`Pág. 2-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
.setImage(``)
msg.edit(adm)
})

let efiltro = (react, user) => react.emoji.name === "numb_3" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let ecoletor = msg.createReactionCollector(efiltro, {time: 500000})
ecoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const diver = new MessageEmbed()
.setAuthor(`| Comandos - Diversão` , `https://cdn.discordapp.com/attachments/715998928390324347/737835112774893608/1595983304438.png`)
.setColor("#009df3")// da sua preferência
.setTitle("")
.setDescription(`\n\n<:ss3ta:738141028682432652>**cafuné** - Faça um cafuné em alguém: m.cafuné <@user>\n<:ss3ta:738141028682432652>**kiss** - Dar um beijo em alguém: m.kiss <@user>\n<:ss3ta:738141028682432652>**slap** - Dar um tapa em algué: m.slap <@user>\n<:ss3ta:738141028682432652>**abraço** - Dar um abraço em alguém: m.abraço <@user>\n<:ss3ta:738141028682432652>**Ship** - Ship duas pessoas: m.ship <@user> <@user>\n<:ss3ta:738141028682432652>**fbi** - Chame o FBI: m.fbi\n<:ss3ta:738141028682432652>**jokempo(Em Breve)** - Jogue pedra-papel-tesoura comigo: m.jokempo <pedra/papel/tesoura>\n<:ss3ta:738141028682432652>**trash** - Jogue alguém no lixo: m.trash <@user>\n<:ss3ta:738141028682432652>**drake** - Drake meme: m.drake <palavra1> <palavra2>\n<:ss3ta:738141028682432652>**primeiraspalavras** - Primeiras palavras: m.pp <palavra>\n<:ss3ta:738141028682432652>**coinflip** - Jogue Cara ou Coroa: m.coinflip <cara/coroa>\n<:ss3ta:738141028682432652>**achievement(Em Breve)** - como usar: m.achievement <conquista>\n<:ss3ta:738141028682432652>**8ball(Em Breve)** - Faça uma pergunta para mim: m.8ball`)
.setFooter(`Pág. 3-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(diver)
})

let ffiltro = (react, user) => react.emoji.name === "numb_4" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let fcoletor = msg.createReactionCollector(ffiltro, {time: 500000})
fcoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const diver = new MessageEmbed()
.setAuthor(`| Comandos - Música` , `https://cdn.discordapp.com/attachments/715998928390324347/737835113026420736/1595983341503.png`)
.setColor("#009df3")// da sua preferência
.setTitle("")
.setDescription(`\n\n<:ss3ta:738141028682432652>**play** - Reproduz uma música em um canal de voz: m.play {nome-da-música}\n<:ss3ta:738141028682432652>**fila** - Mostra as músicas que foram adicionadas a fila: m.fila\n<:ss3ta:738141028682432652>**pause** - Pausa uma música que está sendo reproduzida no momento: m.pause \`use: m.p para despausar uma música\`\n<:ss3ta:738141028682432652>**p** - Despausa a música que foi pausada no canal de voz: m.p\n<:ss3ta:738141028682432652>**skip** - Pula para a próxima música da fila: m.skip\n<:ss3ta:738141028682432652>**stop** - Parar a música que está sendo reproduzida: m.stop\n<:ss3ta:738141028682432652>**leave** - O bot para com todas as músicas e vai embora do canal de voz: m.leave`)
.setFooter(`Pág. 4-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(diver)
})

let afiltro = (react, user) => react.emoji.name === "numb_5" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado
 
 let acoletor = msg.createReactionCollector(afiltro, {time: 500000})
acoletor.on('collect', am => {
am.users.remove(message.author.id)
const adm = new MessageEmbed()
.setAuthor(`| Comandos - Configuração` , `https://cdn.discordapp.com/attachments/715998928390324347/763302547653525544/1602053522383.png`)
.setColor("#009df3")// da sua preferência
.setTitle("")
.setDescription(`\n\n<:ss3ta:738141028682432652>**setwelcome** - Define um canal para anunciar membros que entrarão no servidor: m.setwelcome {#chat}\n<:ss3ta:738141028682432652>**setleave** - Define um canal para anunciar membros que saíram do servidor: m.setleave {#chat}\n<:ss3ta:738141028682432652>**setprefix(Em breve)** - Define um novo prefixo para o bot naquele servidor: m.setprefix {novo-prefixo}`)
.setFooter(`Pág. 5-5 • Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(adm)
})

let fbac = (react, user) => react.emoji.name ===   "se1op" && user.id !== client.user.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado
 
 
 let bcoletor = msg.createReactionCollector(fbac, {time: 500000})
 
 bcoletor.on('collect', back => {
back.users.remove(message.author.id)
 msg.edit(help)
 })
//Apartir daqui faça as outras abas conforme a de moderação
//Coloquei 4 reações, a primeira é pra voltar e as outras 3 : uma p aba de moderação, outra pra aba de diversão e outro pra economia
})
}