const { MessageEmbed } = require("discord.js")

module.exports.run = async (client, message, args, ops) => {

message.delete()
const help = new MessageEmbed()
.setAuthor(client.user.username, client.user.displayAvatarURL())
.setColor("#009df3") //a cor que você quiser aqui 
.setTitle("")
.setDescription(`**Olá, Como posso te ajudar?**
\n<:taxxi:737858861750288444>**Informações:**
Reaja com <:dima2p:737837073326669854> para saber um pouco mais sobre mim e como poderei te ajudá-lo.
\n🗂**Comandos:**\n<:num_1:737837107367903242>│Moderação\n<:num_2:737837143883251833>│Utilitários\n<:num_3:737837176146100255>│Diversão\n<:num_4:737837206705799278>│MineJogos`)
.setImage(`https://cdn.discordapp.com/attachments/707636623545860106/738568436648640633/20200730_222547.jpg`)
.addField("🔗Meus links:", `💎**[Me adicione](https://discordapp.com/oauth2/authorize?client_id=734819851889016902&scope=bot&permissions=4656329)**\n💎**[Server Criador](https://discord.gg/gMuBBX5)**\n💎**[Server Suporte](https://discord.gg/FDKzux4)**`)
.setThumbnail(`https://cdn.discordapp.com/attachments/707636623545860106/715053830332743700/PicsArt_05-27-01.06.52.png`)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()

message.reply(help)
 .then(msg => {
msg.react("738115656125382837")//esse primeiro vai ser a flecha de 
msg.react("737837073326669854")//da aba de muderação
msg.react("737837107367903242")//seria pro de diversao
msg.react("737837143883251833")//seria pro de economia
msg.react("737837176146100255")//Puxar a reação do primeiro emoji com o coletor e responder em outra aba
msg.react("737837206705799278") 
let fbac = (react, user) => react.emoji.name ===   "se1op" && user.id !== client.user.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado
 
 
 let bcoletor = msg.createReactionCollector(fbac, {time: 120000})
 
 bcoletor.on('collect', back => {
back.users.remove(message.author.id)
 msg.edit(help)
 })

 
 let afiltro = (react, user) => react.emoji.name === "dima2p" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado
 
 let acoletor = msg.createReactionCollector(afiltro, {time: 120000})
acoletor.on('collect', am => {
am.users.remove(message.author.id)
const adm = new MessageEmbed()
.setColor("#009df3")// da sua preferência
.setTitle("💗 Sobre Mim 💗")
.setDescription(`\n\n**Olá, Meu nome é Mellone e tenho 16 anos de idade. Sou uma simples Bot criada pelo BioonsYT, Minhas funções são: Administração, Moderação, Interação, Ajuda, Diversão, Entreterimento, entre outras coisas.**\n\n🛠**Minha Versão:** \`v0.2.8\`\n\n📝**Meu nome:** \`Mellone\`\n\n👑**Meu criador:** \`BioonsYT#4834\`\n\n📌**Meu prefixo:** \`m.\`\n\n📆**Fui Criada dia:** \`20 de julho de 2020, às 17:11:44\`\n\n🌐**Servidores:** \`${client.guilds.cache.size}\`\n\n👥**Membros:** \`${client.users.cache.size}\`\n\n📋**Comandos:** \`40\`\n\n📚**Biblioteca:** [Discord.js v12](https://discord.js.org/#/)`)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(adm)
})

let cfiltro = (react, user) => react.emoji.name === "num_1" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let ccoletor = msg.createReactionCollector(cfiltro, {time: 120000})
ccoletor.on('collect', bm => {
bm.users.remove(message.author.id)
const adm = new MessageEmbed()
.setColor("#009df3")// da sua preferência
.setTitle("Comandos - Moderação")
.setDescription(`\n\n<:ss3ta:738141028682432652>**kick**\n\`Use para Expulsar alguém do seu Servidor: m.kick <@user> <motivo>\`\n<:ss3ta:738141028682432652>**ban**\n\`Use para banir alguém do seu Servidor: m.ban <@user> <motivo>\`\n<:ss3ta:738141028682432652>**unban**\n\`Use para desbanir um usuário banido do Servidor: m.unban <id-do-usuário-banido>\`\n<:ss3ta:738141028682432652>**mute**\n\`Use para mutar um usuário do seu Servidor: m.mute <@user> <tempo> <motivo>\`\n<:ss3ta:738141028682432652>**lock/unlock**\n\`Tranca ou Destranca um chat: m.lock/m.unlock\`\n<:ss3ta:738141028682432652>**slowmode**\n\`Escolher o tempo domodo lento do chat: m.slownmode <número-de-segundos>\`\n<:ss3ta:738141028682432652>**clear**\n\`Limpar mensagens do chat: m.clear <número de mensagens para serem apagadas> (No max. 99)\`\n<:ss3ta:738141028682432652>**say**\n\`Fazer Eu falar alguma coisa: m.say <frase>\`\n<:ss3ta:738141028682432652>**dm**\n\`Faça o bot mandar uma mensagem na dm do usuário mencionado: m.dm <@user> <frase>\`\n<:ss3ta:738141028682432652>**warn**\n\`Manda um warn (aviso) na DM do usuário mencionado: m.warn <@user> <aviso>\`\n<:ss3ta:738141028682432652>**Votação(Em breve)**\n\`Faça uma Votação no Servidor: m.votação <frase para votação>\`\n<:ss3ta:738141028682432652>**Sorteio(Beta)**\n\`faça um Sorteio no Servidor: m.sorteio <tempo> <chat-do-sorteio> <prêmio>\``)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(adm)
})

let dfiltro = (react, user) => react.emoji.name === "num_2" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let dcoletor = msg.createReactionCollector(dfiltro, {time: 120000})
dcoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const adm = new MessageEmbed()
.setColor("#009df3")// da sua preferência
.setTitle("Comandos - Utilitários")
.setDescription(`\n\n<:ss3ta:738141028682432652>**help**\n\`Meu Painel de ajuda: m.ajuda\`\n<:ss3ta:738141028682432652>**ping**\n\`Veja meu ping atual: m.ping\`\n<:ss3ta:738141028682432652>**uptime**\n\`Veja o tempo que estou acordada: m.uptime\`\n<:ss3ta:738141028682432652>**serverinfo**\n\`Veja informações do Servidor: m.serverinfo\`\n<:ss3ta:738141028682432652>**userinfo**\n\`Veja informações do usuário mencionado: m.userinfo <@user>\`\n<:ss3ta:738141028682432652>**botinfo**\n\`Veja mais informações sobre mim: m.botinfo\`\n<:ss3ta:738141028682432652>**wikis(Em Breve)**\n\`Criar uma wiki no Servidor: m.wikis <comando>\`\n<:ss3ta:738141028682432652>**cpu**\n\`Veja o uso do meu CPU e Memória RAM: m.cpu\``)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
.setImage(``)
msg.edit(adm)
})

let efiltro = (react, user) => react.emoji.name === "num_3" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let ecoletor = msg.createReactionCollector(efiltro, {time: 120000})
ecoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const diver = new MessageEmbed()
.setColor("#009df3")// da sua preferência
.setTitle("Comandos - Diversão")
.setDescription(`\n\n<:ss3ta:738141028682432652>**cafuné**\n\`Faça um cafuné em alguém: m.cafuné <@user>\`\n<:ss3ta:738141028682432652>**kiss**\n\`Dar um beijo em alguém: m.kiss <@user>\`\n<:ss3ta:738141028682432652>**slap**\n\`Dar um tapa em algué: m.slap <@user>\`\n<:ss3ta:738141028682432652>**abraço**\n\`Dar um abraço em alguém: m.abraço <@user>\`\n<:ss3ta:738141028682432652>**Ship**\n\`Ship duas pessoas: m.ship <@user> <@user>\`\n<:ss3ta:738141028682432652>**fbi**\n\`Chame o FBI: m.fbi\`\n<:ss3ta:738141028682432652>**jokempo(Em Breve)**\n\`Jogue pedra-papel-tesoura comigo: m.jokempo <pedra/papel/tesoura>\`\n<:ss3ta:738141028682432652>**trash(Em breve)**\n\`Jogue alguém no lixo: m.trash <@user>\`\n<:ss3ta:738141028682432652>**drake(Em breve)**\n\`Drake meme: m.drake <palavra1> <palavra2>\`\n<:ss3ta:738141028682432652>**roleta-russa(em breve)**\n\`como usar: m.roleta-russa\`\n<:ss3ta:738141028682432652>**coinflip**\n\`Jogue Cara ou Coroa: m.coinflip <cara/coroa>\`\n<:ss3ta:738141028682432652>**achievement(Em Breve)**\n\`como usar: m.achievement <conquista>.\`\n<:ss3ta:738141028682432652>**8ball(Em Breve)**\`Faça uma pergunta para mim: m.8ball\``)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(diver)
})

let ffiltro = (react, user) => react.emoji.name === "num_4" && user.id === message.author.id;// no emoji aqui pode ser o proprio emoji se for do discord ja, ou o nome dele se for personalizado

let fcoletor = msg.createReactionCollector(ffiltro, {time: 120000})
fcoletor.on('collect', cm => {
cm.users.remove(message.author.id)
const diver = new MessageEmbed()
.setColor("#009df3")// da sua preferência
.setTitle("Comandos - Economia")
.setDescription(`**Comandos de Economia EM BREVE!!!**`)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()
msg.edit(diver)
})
//Apartir daqui faça as outras abas conforme a de moderação
//Coloquei 4 reações, a primeira é pra voltar e as outras 3 : uma p aba de moderação, outra pra aba de diversão e outro pra economia
})
}