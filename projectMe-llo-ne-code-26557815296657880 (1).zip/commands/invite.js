const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

message.delete()
const exampleEmbed = new Discord.MessageEmbed()
.setColor('Color')
.setThumbnail(client.user.displayAvatarURL())
.setDescription(`**Olá ${message.member.user}, Meu nome é Mellone e tenho 16 anos de idade. Sou uma simples Bot criada pelo BioonsYT, Minhas funções são: Administração, Moderação, Interação, Ajuda, Diversão, Entretenimento, entre outras coisas.**`)
.addField("🔗Links Importantes:", `💎**[Me adicione](https://discordapp.com/oauth2/authorize?client_id=734819851889016902&scope=bot&permissions=4656329)**\n💎**[Vote em mim](https://botsparadiscord.com/bots/734819851889016902)**\n💎**[Servidor de Suporte](https://discord.gg/PrsAtP3)**`)
.setFooter(`Executado por: ${message.author.tag}`, message.author.displayAvatarURL())
.setTimestamp()

await message.channel.send(exampleEmbed);

}