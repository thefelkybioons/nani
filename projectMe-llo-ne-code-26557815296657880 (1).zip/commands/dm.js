module.exports = {
  name: "dm",
  description: "Mandar mensagem na dm de algum usuário",
  category: "mod",
  run: async (bot, message, args, ops) => {
    if (!message.member.permissions.has("ADMINISTRATOR"))
      return message.channel.send("**Ops você não tem permissão para executar esse comando!**");
    let user =
      message.mentions.members.first() ||
      message.guild.members.cache.get(args[0]);
    if (!user)
      return message.channel.send(
        `Você precisa mencionar um usuário!`
      );
    if (!args.slice(1).join(" "))
      return message.channel.send("Você precisa definir uma mensagem para enviar para o user");
    user.user
      .send(args.slice(1).join(" "))
      .catch(() => message.channel.send("That user could not be DMed!"))
      .then(() => message.channel.send(`Sua mensagem foi enviada na dm do; ${user.user.tag}`));
  },
};