const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')

exports.run = async (client, message, args, ops) => {
  if(!message.member.permissions.has("ADMINISTRATOR")) return message.reply("**Ops Você não tem permissão de ADMINISTRATOR para executar esse comando!**")
let
   channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

  if(!args[0]) return message.reply("**Você precisa mencionar um canal!**")

  let wc = db.get(`welcomechannel_${message.guild.id}`)

  try {
      db.set(`bemvindo_${message.guild.id}`,  channel.id)
      message.channel.send(new Discord.MessageEmbed()
      .setDescription(`Anúncios de boas-vindas setado no canal: ${channel}**, agora as mensagens de bem vindo seram anunciadas lá**`)
      .setColor(`RED`)) 
  } catch (err) {
    console.error("Erro: " + err)
  }
}