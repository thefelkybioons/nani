const { MessageEmbed } = require('discord.js');
const moment = require('moment');

const filterLevels = {
	DISABLED: 'Off',
	MEMBERS_WITHOUT_ROLES: 'Nenhuma role',
	ALL_MEMBERS: 'Everyone'
};

const verificationLevels = {
	NONE: 'Nenhum',
	LOW: 'Baixo',
	MEDIUM: 'Médio',
	HIGH: 'High',
	VERY_HIGH: 'Very_High'
};

const regions = {
	brazil: 'Brazil',
	europe: 'Europe',
	hongkong: 'Hong Kong',
	india: 'India',
	japan: 'Japan',
	russia: 'Russia',
	singapore: 'Singapore',
	southafrica: 'South Africa',
	sydeny: 'Sydeny',
	'us-central': 'US Central',
	'us-east': 'US East',
	'us-west': 'US West',
	'us-south': 'US South'
};

module.exports = {
    name: "serverinfo",
    category: "info",
    aliases: ["server", "guild", "guildinfo"],
    description: "Pegar informações do servidor",
    run: async (client, message, args, ops) => {
		const roles = message.guild.roles.cache.sort((a, b) => b.position - a.position).map(role => role.toString());
		const members = message.guild.members.cache;
		const channels = message.guild.channels.cache;
		const emojis = message.guild.emojis.cache;

		const embed = new MessageEmbed()
			.setDescription(`<a:dc:725111756032311448>**Informações do Servidor: __${message.guild.name}__**`)
			.setColor('BLUE')
			.setThumbnail(message.guild.iconURL({ dynamic: true }))
			.addField('**Geral:**', [ `**<:jnl:741357277935829059>Nome:** \n\`${message.guild.name}\``,
				`**<:cxa:741356544654049321>ID:** \n\`${message.guild.id}\``,
				`**<:cwr:741356403616383026>Dono:** \n\`${message.guild.owner.user.tag}\``,
				`**🌐Região:** \n\`${regions[message.guild.region]}\``,
				`**📊Nível de verificação:** \n\`${verificationLevels[message.guild.verificationLevel]}\``,
				`**📆Servidor criado em:** \n\`${moment(message.guild.createdTimestamp).format('LT')} ${moment(message.guild.createdTimestamp).format('LL')} ${moment(message.guild.createdTimestamp).fromNow()}\``,
				`**<:boost:747162737335074847>Impulsos:** \n\`${message.guild.premiumSubscriptionCount || '0'}\``,
				`**<:booste_gg:762953265163010048>Nível de impulso:** \n\`${message.guild.premiumTier ? `Nível: ${message.guild.premiumTier}` : 'Sem Nível'}\``,
			])
			.addField('**Estatísticas:**', [
				`**💼Cargos:** \`${roles.length}\``,
				`**🖌Emojis:** \`${emojis.size}\``,
				`**<:menbers:762948563411664897>Humanos:** \`${members.filter(member => !member.user.bot).size}\``,
				`**<:butzin:744448182829711360>Bots:** \`${members.filter(member => member.user.bot).size}\``,
				`**<:Channel:746831671353147453>Canais de texto:** \`${channels.filter(channel => channel.type === 'text').size}\``,
				`**<:voz_59_ch:762952455151419404>Canais de voz:** \`${channels.filter(channel => channel.type === 'voice').size}\``,
			])
			.addField('**Presença:**', [
				`**👥Membros:** \`${message.guild.memberCount}\``,
				`**<:onln:741363837797924957>Online:** \`${members.filter(member => member.presence.status === 'online').size}\``,
				`**<:dndd:741363765794045972>Ausente:** \`${members.filter(member => member.presence.status === 'idle').size}\``,
				`**<:nptb:741363797805105352>Não perturbe:** \`${members.filter(member => member.presence.status === 'dnd').size}\``,
				`**<:offl:741363657920741386>Offline:** \`${members.filter(member => member.presence.status === 'offline').size}\``,
			])
      .setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
      .setTimestamp()
		message.channel.send(embed);
	}

};