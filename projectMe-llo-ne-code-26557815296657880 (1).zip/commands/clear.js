const Discord = require("discord.js");

exports.run = async (client, message, args, ops) => {
  if (!message.member.permissions.has("MANAGE_MESSAGES"))
    return message.reply(
      "Ops lhe falta permissão de `Gerenciar Mensagens` para usar esse comando"
    );
  const deleteCount = parseInt(args[0], 10);
  if (!deleteCount || deleteCount < 2 || deleteCount > 99)
    return message.reply(
      "forneça um número de **1 até 99 mensagens** para serem excluídas"
    );

  const fetched = await message.channel.messages.fetch({
    limit: deleteCount + 1
  });
  message.channel.bulkDelete(fetched);
  message.channel
    .send(`**Chat foi limpo por: ${message.author.username}**\n🗑Foram apagadas: **${args[0]} mensagens!**`).then(msg => msg.delete({timeout: 5000}))
    .catch(error =>
      console.log(`Não foi possível deletar mensagens devido a: ${error}`)
    );
};