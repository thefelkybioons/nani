const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

var list = [
  'https://imgur.com/iclUiUN.gif',
  'https://imgur.com/lYQt9rx.gif',
  'https://imgur.com/w1TU5mR.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680104333312020/6fc25fdd3e22d89b19c3ea76d11789e6.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711684572311584860/126569.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711684571732639804/tenor_3.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680314421805086/tenor_1.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680161644412959/gif_288.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680104828239882/c1e198a514380ebc2956734024a815c9.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680104333312020/6fc25fdd3e22d89b19c3ea76d11789e6.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/711680103964213350/gif_286.gif',
  'https://loritta.website/assets/img/actions/kiss/female_x_male/gif_379.gif;https://cdn.discordapp.com/attachments/682314058778804264/691756337050419220/giphy_2.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/715382756296753162/tenor_6.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/715382756611457114/tenor_1.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/715382757085282444/tenor_2.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('você precisa mencionar alguém para beijalo(a)!');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! ❤️`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`💕**O Amor está no ar:** ${message.author} **acaba de beijar:** ${user}`)
        .setImage(rand)
        .setFooter('😙')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}