const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

var list = [
  'https://imgur.com/87jyaIa.gif',
  'https://imgur.com/kebLvpS.gif',
  'https://media.tenor.com/images/49dc9058b390fcec0a9ebbe71a2f82af/tenor.gif',
  'https://media.tenor.com/images/cee298437607d7b123bc9664c9ce844b/tenor.gif',
  'https://media.tenor.com/images/ca682cecd6bff521e400f984502f370c/tenor.gif',
  'https://media.tenor.com/images/6b371d1268accf30a8afe15d63f977e0/tenor.gif',
  'https://media.tenor.com/images/8d33eeee359d0453de52c5779dd23c46/tenor.gif',
  'https://media.tenor.com/images/7a6c91842f8b2871ecf5234bcd095da7/tenor.gif',
  'https://media.tenor.com/images/3d9c3a9c945fa8d27e6d3a0e1ec83f03/tenor.gif',
  'https://media.tenor.com/images/61ea96bce16c53a913336a3dbc1a6100/tenor.gif',
  'https://media.tenor.com/images/35fc88f417892fad929380ad78c796b9/tenor.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let membro = message.mentions.members.first() || message.guild.members.cache.get(args[0])
if (!membro) return message.reply('**Você precisa mencionar alguém pra abraçar!**');
if(membro.user.id === message.author.id) {
    return message.reply("Você não pode se abraçar!")
}

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#882D61')
        .setDescription(`💖**Que lindo!!!** ${message.author} **acaba de abraçar:** ${membro}`)
        .setImage(rand)
        .setFooter('😊')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}