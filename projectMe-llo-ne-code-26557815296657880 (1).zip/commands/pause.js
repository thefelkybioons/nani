const Discord = require("discord.js");
const yts = require('youtube-search');

const ytdl = require('ytdl-core');

exports.run = (client, message, args, ops) => {
    let fetched = ops.active.get(message.guild.id);
    if (!fetched) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops, Neste momento não Estou reproduzindo nen uma música!**`)
    .setColor('RED'));

    if (message.member.voice.channel !== message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops você não está conectado no meu Canal De Voz!**`)
    .setColor('RED'));





    ops.active.get(message.guild.id, fetched);


        const embedPause = new Discord.MessageEmbed()
        .setDescription(`**A Música Atual Foi Pausada Com Sucesso!**\n> **Use:** \`m.p\` *para despausar a música!*`)
  
        .setColor("RED");
       
        message.channel.send(embedPause);

        fetched.dispatcher.pause(true);
    
};