const Discord = require('discord.js')
const config = require('../config.json')

exports.run = (client, message, args, ops) => {
 
    if (message.member.voice.channel !== message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Você Não está conectado em nem um Canal De Voz!**`)
    .setColor('RED'));
message.guild.me.voice.channel.leave();
const embed1 = new Discord.MessageEmbed()
.setColor('RED')
.setDescription(`**Bye Bye, Estou Me desconectando Do Canal de voz!**`)
message.channel.send(embed1)
}