const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

var list = [
  'https://i.imgur.com/GPQJEx5.gif',
  'https://i.imgur.com/fm49srQ.gif',
  'https://i.imgur.com/Li9mx3A.gif',
  'https://i.imgur.com/CwbYjBX.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/712057734392053770/tapas.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/712057733205196810/tenor.gif',
  'https://cdn.discordapp.com/attachments/710266471837859864/712057733851119626/a59df307e6bb26c6c0f1d726675ee934.gif',
  'https://media1.giphy.com/media/mEtSQlxqBtWWA/giphy.gif?cid=19f5b51a5d0007c26844576955890a26&rid=giphy.gif',
  'https://media3.giphy.com/media/uqSU9IEYEKAbS/giphy.gif?cid=19f5b51a5d00203538356441459270c9&rid=giphy.gif',
  'https://media1.giphy.com/media/6Fad0loHc6Cbe/giphy.gif?cid=19f5b51a5d00203538356441459270c9&rid=giphy.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('lembre-se de mencionar um usuário válido para tapear!');
}
/*
message.channel.send(`${message.author.username} **acaba de tapear** ${user.username}!️`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`💥**Não mexa com quem ta quieto** ${message.author} **acaba de dar um tapa em:** ${user}`)
        .setImage(rand)
        .setFooter('💥')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}