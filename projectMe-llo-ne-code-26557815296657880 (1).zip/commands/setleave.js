const Discord = require('discord.js')
const db = require('quick.db')
const config = require('../config.json')

exports.run = async (client, message, args, ops) => {
  if(!message.member.permissions.has("ADMINISTRATOR")) return message.reply("**Ops Você não tem permissão de ADMINISTRATOR para executar esse comando!**.")
let
   channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

  if(!args[0]) return message.reply("Menione um canal.")

  let sc = db.get(`saidachannel_${message.guild.id}`)

  try {
      db.set(`saida_${message.guild.id}`,  channel.id)
      message.channel.send(new Discord.MessageEmbed()
      .setDescription(`Anúncios de saida setado no canal: ${channel}**, agora as mensagens de saida seram anunciadas lá**`)
      .setColor(`RED`)) 
  } catch (err) {
    console.error("Erro: " + err)
  }
}