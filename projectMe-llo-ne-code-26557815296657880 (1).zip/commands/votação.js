const Discord = require("discord.js");

module.exports.run = async (client, message, args, ops) => {

    if(!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("**Você não tem permissão para executar este comando, requerimento:** MANAGE_CHANNELS");

    let usuario = message.author

    if(!args[0]) return message.channel.send(`${usuario}, **Por favor, insira alguma mensagem para iniciar uma votação!**`);

    let mensagem = args.slice(" ").join(" ");

    const votacao = new Discord.MessageEmbed()
    .setColor("RANDOM")
    .setTitle(`🗳Votação🗳`)
    .setDescription(mensagem)
    .setFooter(`Por: ${usuario.tag}`, message.author.displayAvatarURL({format: "png"}))
    .setTimestamp();
    message.channel.send(votacao).then(msg => {
        msg.react("✅");
        msg.react("❌");
    })
}