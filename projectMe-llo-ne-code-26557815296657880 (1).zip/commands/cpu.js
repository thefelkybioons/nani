const Discord = require("discord.js")

module.exports.run = (bot, message, args, ops) => {
    const status = new Discord.MessageEmbed()
        .setTitle('📈Status:')
        .addField('<:ccppuu:746832464986767451>__Uso do CPU__:', `**•${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%**`)
        .addField('<:ramm:741362702529855568>__Uso de RAM__:', `**•${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB**`)
message.reply(status)
}