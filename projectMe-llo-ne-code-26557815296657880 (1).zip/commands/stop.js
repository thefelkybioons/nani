const Discord = require('discord.js')
exports.run = (client, message, args, ops) => {
   let fetched = ops.active.get(message.guild.id);
    if (ops.active.get(message.guild.id)) ops.active.delete(message.guild.id);
    
    if (!message.member.voice.channel) return message.channel.send(new Discord.MessageEmbed()
  .setColor('RED')
  .setDescription(`**Você precisa está conectado em um canal de voz para mim poder parar a música!**`));
    if (!message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops, não estou tacando nem uma música no momento!**`)
    .setColor('RED'))
    if (message.member.voice.channel !== message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops Você Não esta conectado no meu Canal De Voz!**`)
    .setColor('RED'));

     message.guild.me.voice.channel.leave();
    message.channel.send(new Discord.MessageEmbed()
    .setColor('RED')
    .setDescription(`**Eu Parei de Tocar Todas as Musicas, e estou me Desconectando Do canal de voz atual Bye Bye!**`))
};