const Discord = require('discord.js');
const fs = require('fs');
const length = fs.readdirSync('./commands').length;

exports.run = async (client, message, args, ops) => {

message.delete()
const exampleEmbed = new Discord.MessageEmbed()
.setAuthor(client.user.username, client.user.displayAvatarURL())
.setTitle("")
.setColor('Color')
.setThumbnail(client.user.displayAvatarURL())
.setDescription(`\n\n**Olá** ${message.member.user}\n\n🌍**Estou em: ${client.guilds.cache.size} Servidores**\n\n:speech_balloon: **Em: ${client.channels.cache.size} Canais**\n\n👥**Com: ${client.users.cache.size} Usuários**\n\n📨**Me adicione ao seu Servidor: [invite](https://discordapp.com/oauth2/authorize?client_id=734819851889016902&scope=bot&permissions=4656329)**\n\n<:psc:741357025090600980>**Servidor de Suporte: [clique aqui](https://discord.gg/PrsAtP3)**\n\n<:penamine:741362754107211866>**Minha Versão:** \`v0.2.8\`\n\n<:cxa:741356544654049321>**Meu ID:** \`734819851889016902\`\n\n<:cwr:741356403616383026>**Meu criador:** \`</BioonsYT>#4834\`\n\n📌**Meu prefixo:** \`m.\`\n\n📆**Fui Criada dia:** \`20 de julho de 2020, às 17:11:44\`\n\n📡**Meu Ping:** \`${Math.round(client.ws.ping)}ms\`\n\n<:ramm:741362702529855568>**Memória:** \`${(process.memoryUsage().rss / 1024 / 1024).toFixed(2)}MB\`\n\n<:ccppuu:746832464986767451>**Cpu:** \`${(process.cpuUsage().system / 1024 / 1024).toFixed(2)}%\`\n\n<:dacl:741941439465914378>**Hospedado na:** \`Discloud\`\n\n<:pats:741356866201714738>**Comandos:** \`${length}\`\n\n<:js_js:741043406867791942>**Linguagem: [JavaScript](https://www.javascript.com/)**\n\n📚**Biblioteca: [Discord.js v12](https://discord.js.org/#/)**`)
.setFooter(`Comando Requisitado por: ${message.author.tag}`, message.author.avatarURL({dynamic: true, size: 512}))
.setTimestamp()

await message.channel.send(exampleEmbed);

}