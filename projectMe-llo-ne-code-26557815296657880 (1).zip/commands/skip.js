  const Discord = require("discord.js");
const yts = require('youtube-search');
const ytdl = require('ytdl-core');
exports.run = (client, message, args, ops) => {
    let fetched = ops.active.get(message.guild.id);
    if (!fetched) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`Ops, não estou tocando nem uma música no momento!**`)
    .setColor('RED'));

    if (message.member.voice.channel !== message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Você Não esta conectado no meu Canal De Voz**!`)
    .setColor('RED'));

    let userCount = message.member.voice.channel.members.size;
    let required = Math.ceil(userCount/2);

    if (!fetched.fila[0].voteSkips) fetched.fila[0].voteSkips = [];
    if (fetched.fila[0].voteSkips.includes(message.member.id)) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops Você já Votou Para Pular a música,** **é necessário no mínimo** ${required} **Votos para pular para a próxima música!**`)
    .setColor(`RED`));

    fetched.fila[0].voteSkips.push(message.member.id);

    ops.active.get(message.guild.id, fetched);

    if (fetched.fila[0].voteSkips.length >= required) {
        const embedSucesso = new Discord.MessageEmbed()
        .setDescription(`**A Música Atual Foi Pulada com Sucesso!**`)
        .setColor("RED");
        message.channel.send(embedSucesso);

        return fetched.dispatcher.emit('finish');
    }

    message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Você Votou Para Pular a Música,** **é necessário ${required} **Votos para pular a música!**`)
    .setColor(`RED`))
};