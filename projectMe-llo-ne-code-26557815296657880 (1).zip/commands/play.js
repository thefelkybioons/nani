const Discord = require("discord.js");
// Troquei o "yt-search" para "youtube-search".
const yts = require('youtube-search');
const axios = require('axios')
const ytdl = require('ytdl-core');
const moment = require("moment");
var opts = yts.YouTubeSearchOptions = {
    maxResults: 10,
    key: "AIzaSyBJFha1SqX8md4NdFEMR-D8Z49QXU51qZQ"
};

exports.run = async (client, message, args, ops) => {
    if (!message.member.voice.channel) return message.channel.send(new Discord.MessageEmbed()
  .setColor('RED')
  .setDescription(`**Você precisa está conectado a um canal de voz para mim reproduzir uma música!**`))

    let pesq = args.join(" ");
    if (!pesq) return message.channel.send(new Discord.MessageEmbed()
  .setDescription('**Digite o nome ou o link da música que deseja reproduzir!**')
  .setColor("RED"));

    // função de pesquisa
    yts(pesq, opts, async function(err, res) {
        if (err) console.log(err);
        let a = res[0];

        await ytdl.getInfo(a.id , async function(err, rVideo) {

            let data = ops.active.get(message.guild.id) || [];

            if (!data.connection) data.connection = await message.member.voice.channel.join();
            if (!data.fila) data.fila = new Array();
            data.guildID = message.guild.id;

            let rTempo = moment.utc(rVideo.videoDetails.lengthSeconds*1000).format("HH:mm:ss");

            data.fila.push({
                titulo: rVideo.videoDetails.title,
                url: rVideo.url,
                views: rVideo.short_view_count_text,
                tempo: rTempo,
                author: message.author.tag
            });

            if (!data.dispatcher) tocar(client, ops, data);
            else {
                message.channel.send(new Discord.MessageEmbed()
                .setTitle(`🎙️Música Adicionada a fila!`)
                .setDescription(`> **Nome da Música:** \`${rVideo.videoDetails.title}\`\n**Adicionada por:** ${message.author}`)
                .setFooter(`ID do Usuário: ${message.author.id}`)
                .setTimestamp()
                .setColor(`#0F0020`))
            }
				
            ops.active.set(message.guild.id, data)
        });
    });

    // tocar a música
    async function tocar(client, ops, data) {
        let embed = new Discord.MessageEmbed()
        .setTitle(`🎵**Reproduzindo:** ${data.fila[0].titulo}`)
        .setDescription(`> 👤**Por:** \`${data.fila[0].author}\`\n> 🕓**Duração da música:** \`${data.fila[0].tempo}\``)
        .setFooter(`ID do Usuário: ${message.author.id}`)
        .setTimestamp()

        .setColor("RED");
        message.channel.send(embed);

  data.dispatcher = await data.connection.play(ytdl(data.fila[0].url, {filter: 'audioonly'}));
        data.dispatcher.guildID = data.guildID;

        // Quando a música acabar, ele executa o finalizar();
        data.dispatcher.once('finish', function() {
            finalizar(client, ops, this);
        });
    };

    function finalizar(client, ops, dispatcher) {
        let fetched = ops.active.get(dispatcher.guildID);
        // tira o primeiro item da fila, no caso o que acabou de tocar.
        fetched.fila.shift();
        
        // se ainda tiver algo na fila
        if (fetched.fila.length > 0) {
            ops.active.set(dispatcher.guildID, fetched);
            tocar(client, ops, fetched);

        // se não tiver mais nada na fila, ele sai do canal.
        } else { 
            ops.active.delete(dispatcher.guildID);
            let vc = client.guilds.cache.get(dispatcher.guildID).me.voice.channel;
            if (vc) vc.leave();
            message.channel.send(new Discord.MessageEmbed()
            .setDescription(`👋**Bye Bye, Saindo Por Inatividade!**`)
            .setColor(`RED`))
        }   
    };
};