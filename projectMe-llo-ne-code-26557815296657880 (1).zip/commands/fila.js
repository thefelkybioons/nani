const Discord = require("discord.js");
exports.run = (client, message, args, ops) => {
    let fetched = ops.active.get(message.guild.id);
    if (!fetched) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops, não a nem uma música na fila para ser reproduzida!**`)
    .setColor('RED'))

    let fila = fetched.fila;
    let tocandoAgora = fila[0];

    let resp = `> **1** Tocando agora: \`${tocandoAgora.titulo}\``

    for (i = 1; i < fila.length; i++) {
        resp += `\n> **${i+1}** \`${fila[i].titulo}\` ***\`[${fila[i].tempo}]\`***`
    }
    let embed = new Discord.MessageEmbed()
    .setTitle("🎙️Informações da fila!")
    .setDescription(`${resp}`)
    .setFooter(`ID do Usuário: ${message.author.id}`)
    .setTimestamp()
    .setColor("RED");
    message.channel.send(embed)
}