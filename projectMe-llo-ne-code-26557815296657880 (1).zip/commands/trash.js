const discord = require('discord.js')

module.exports = {
 name:"trash",
 aliases: ['lixo'],
 run: async (client, message, args, ops) => {
 const member = message.mentions.users.first();
 if(!member) return message.channel.send('Você precisa mencionar alguém para jogar no lixo!')
 if(message.author.id === member.id) return message.channel.send('Você não pode se jogar no  lixo!')
 let embed = new discord.MessageEmbed()
 .setColor("#000000")
 .setTitle("Aqui e sua casa!")
 .setImage(`https://api.alexflipnote.dev/trash?face=${message.author.displayAvatarURL({ dynamic : true })}&trash=${member.displayAvatarURL({ dynamic : true })}`);
 
 message.channel.send(embed)
 }
}