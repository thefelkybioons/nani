const Discord = require("discord.js")

module.exports.run = async (client, message, args, ops) => {
  message.delete()
  if(!message.member.permissions.has("KICK_MEMBERS")) {
    return message.reply("Ops Você não tem a permissão necessária!")
  }
  
  if(!message.guild.me.permissions.has("KICK_MEMBERS")) {
    return message.reply("Eu não tenho a permissão necessária!")
  }
  
  let membro = message.mentions.members.first() || message.guild.members.cache.get(args[0])
  if(!membro) return message.reply("Você precisa mencionar um usuário válido deste servidor!")
  if(membro.user.id === message.author.id) {
    return message.reply("Você não pode se expulsar!")
  }
  if(membro.user.id === client.user.id) {
    return message.reply("Por que você quer me expulsar?")
  }
  if(!membro.kickable) {
    return message.reply("Eu não posso expulsar este usuário, meu cargo é menor que o do usuário a ser punido! Para que eu possa punir, suba o meu cargo para o topo na lista de cargos, obrigada!")
  }
  if(membro.permissions.has("ADMINISTRATOR")) {
    return message.reply("Eu não posso expulsar este usuário, meu cargo é menor que o do usuário a ser punido! Para que eu possa punir, suba o meu cargo para o topo na lista de cargos, obrigada!")
  }
  
  let motivo = args.slice(1).join(" ")
  if(!motivo) motivo = "Não Definido"
  
  message.delete()
  const embed = new Discord.MessageEmbed()
  .setTitle("❌Membro Expulso!")
  .setColor("#bb00ff")
  .addField("👤Membro:", membro.user.tag, false)
  .addField("👮Moderador:", message.member.user, false)
  .addField("📝Motivo:", motivo, false)
  message.channel.send(embed)
  membro.kick({reason: motivo})
  
}