const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

var list = [
'https://cdn.discordapp.com/attachments/740978865689591809/741402046871371836/tenor-1.gif',
'https://cdn.discordapp.com/attachments/740978865689591809/741402047198396457/725dc89e753464fef940ea554e999b5bdcdb1c45_hq.gif',
'https://cdn.discordapp.com/attachments/740978865689591809/741402066324553768/1434336660_hQ6Fktz.gif',
'https://cdn.discordapp.com/attachments/740978865689591809/741402066844647534/5acf256d2e58322113c5d5664550b6e58a8adb99r1-400-225_hq.gif',
'https://cdn.discordapp.com/attachments/740978865689591809/741402095474835627/gif_2.gif',
'https://cdn.discordapp.com/attachments/740978865689591809/741402096728932442/gif_0.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('**Você precisa mencionar um usuário válido para fazer um cafuné!**');
}
/*
message.channel.send(`${message.author.username} **fez um cafuné em:** ${user.username}! ❤️`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('')
        .setColor('#000000')
        .setDescription(`💕**Que fofo!!!** ${message.author} **fez um cafuné em:** ${user}`)
        .setImage(rand)
        .setFooter('💕')
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
}