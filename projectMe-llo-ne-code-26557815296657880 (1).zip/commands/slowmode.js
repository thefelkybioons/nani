module.exports = {
  name: "slowmode",
  aliases:['modolento'],
  run: async (bot, message, args) => {
      if(!message.guild.me.permissions.has("MANAGE_CHANNELS")) return message.reply(`**Ops não tenho permissão para executar esse comando!**`)
      
      if (!message.member.permissions.has("MANAGE_CHANNELS"))
    return message.reply(
      ":errado: **Ops você precisa de permissão de MANAGE_CHANNELS para executar esse comando**"
    );
    if (!args[0])
      return message.channel.send(
        `**Você precisa adicionar um tempo para o slowmode! ex: m.slowmode <5>**`
      );
    if (isNaN(args[0])) return message.channel.send(`**Ops, Isso não é um número!**`);

    message.channel.setRateLimitPerUser(args[0]);
    message.channel.send(
    "⏱️ **O Slowmode do chat foi definido para:** " + args[0] + " **segundos!**"
    );
  },
};