const Discord = require('discord.js')
const yts = require('youtube-search');
const ytdl = require('ytdl-core');

exports.run = (client, message, args, ops) => {
     let fetched = ops.active.get(message.guild.id);
    if (!fetched) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops, não estou reproduzindo nem uma música no momento!**`)
    .setColor('RED'));

    if (message.member.voice.channel !== message.guild.me.voice.channel) return message.channel.send(new Discord.MessageEmbed()
    .setDescription(`**Ops Você Não esta conectado no meu Canal De Voz!**`)
    .setColor('RED'));





    ops.active.get(message.guild.id, fetched);


        const embedUmpause = new Discord.MessageEmbed()
        .setDescription(`**A Música atual Foi Despausada Com Sucesso!**\n> **Use:** \`m.pause\` *para pausar a música novamente!*`)

        .setColor("RED");
       
        message.channel.send(embedUmpause);

        fetched.dispatcher.resume(true);
}