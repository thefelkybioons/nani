const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

message.delete()
const exampleEmbed = new Discord.MessageEmbed()
.setTitle ("🕵FBI na Área🕵")
.setColor('Color')
.setImage(`https://media.discordapp.net/attachments/707669648140664945/709068523854626866/desconhecido.gif`)
.setDescription(`${message.member.user} **chamou o FBI**\n\n📣**Estamos invadindo!!!**`)
.setFooter(`Ocasionado por: ${message.author.tag} | chame o fbi use: m.fbi`, message.author.displayAvatarURL());

await message.channel.send(exampleEmbed);

}