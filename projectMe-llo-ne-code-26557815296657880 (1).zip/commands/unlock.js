const Discord = require("discord.js")
exports.run = (client, message, args, ops) => {
 if (!client.lockit) client.lockit = [];
  if(!message.guild.me.permissions.has("MANAGE_CHANNELS")) {
    return message.reply("Me desculpe mas eu não tenho permissão de Gerenciar canais")
  }
 if (!message.member.hasPermission("MANAGE_CHANNELS")) return message.reply("**Ops Você nao tem permissão para usar este comando** "); message.channel.createOverwrite(message.guild.id, {
 SEND_MESSAGES: null 
 })
  const embed = new Discord.MessageEmbed()
  .setColor("#e0363e")
  .setDescription(`**🔓Canal destrancado com sucesso!**`)
  message.channel.send(embed)
  message.delete()
 };