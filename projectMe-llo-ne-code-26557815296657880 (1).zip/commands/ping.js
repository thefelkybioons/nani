const Discord = require('discord.js');

exports.run = async (client, message, args, ops) => {

const exampleEmbed = new Discord.MessageEmbed()
.setTitle(`🏓 | Pong!`)
.setColor('#FF0000')
.setDescription(`<:pig:746831731012927578> Meu ping é: **${Math.round(
      client.ws.ping
    )}ms**`)

await message.channel.send(exampleEmbed);

}