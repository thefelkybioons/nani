const express = require('express');
const db = require('quick.db')
const moment = require('moment');
moment.locale('pt-br');
const app = express();
app.get("/", (request, response) => {
  const ping = new Date();
  ping.setHours(ping.getHours() - 3);
  console.log(`Ping recebido às ${ping.getUTCHours()}:${ping.getUTCMinutes()}:${ping.getUTCSeconds()}`);
  response.sendStatus(200);
});
app.listen(process.env.PORT); // Recebe solicitações que o deixa online

const Discord = require("discord.js"); //Conexão com a livraria Discord.js
const client = new Discord.Client(); //Criação de um novo Client
const config = require("./config.json"); //Pegando o prefixo do bot para respostas de comandos

//Musica
let active = new Map();
let ops = { active: active }
//

client.on('message', message => {
     if (message.author.bot) return;
     if (message.channel.type == 'dm') return;
     if (!message.content.toLowerCase().startsWith(config.prefix)) return;
     if (message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)) return;

    const args = message.content
        .trim().slice(config.prefix.length)
        .split(/ +/g);
    const command = args.shift().toLowerCase();

    try {
        const commandFile = require(`./commands/${command}.js`)
        commandFile.run(client, message, args, ops,);
    } catch (err) {
    console.error('Erro:' + err);
    const erro = new Discord.MessageEmbed()
      .setAuthor(client.user.username, client.user.displayAvatarURL())
    .setTitle(`**Ops Comando não encontrado, verifique sua ortografia!!!**`)
    .setColor(`#882D61`)
    .setDescription(`**Utilize:** \`${config.prefix}help\` **para ver meus comandos!**`)
    .setFooter(``)
    .setThumbnail(``) 
// de baixo do console.log(err) 
return message.channel.send(erro).then(msg => msg.delete({timeout: 5000}))
    }
});


client.on('guildMemberAdd',async member => {
const db = require('quick.db');
var wchannel = db.get(`bemvindo_${member.guild.id}`);

//embed
let embed = new Discord.MessageEmbed()
.setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
      .setAuthor(member.user.tag, member.user.displayAvatarURL())
.setTitle(`Boas-Vindas!`)
      .setImage("https://cdn.discordapp.com/attachments/715998928390324347/730479902800871525/tenor-1.gif")
.setDescription(`<a:tp:725111678588420168> **Olá ${member.user}, Seja muito bem-vindo(a) ao Servidor!**\n💫 **Atualmente estamos com: ${member.guild.memberCount} membros, Divirta-se conosco! ❤️**`)
.setColor('GREEN')
.setTimestamp();
//

//procurar canal
const WCHANNEL = member.guild.channels.cache.find(channel => channel.id === `${wchannel}`) 
if(WCHANNEL) { 
WCHANNEL.send(embed)
}
});


client.on('guildMemberRemove', async member => {
var schannel = db.get(`saida_${member.guild.id}`);
let embed = new Discord.MessageEmbed()
.setTitle('😔 Adeus!')
.setAuthor(member.user.tag, member.user.displayAvatarURL())
.setDescription(`**${member.user.tag}**, saiu do servidor! 💔`)
.setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
.setTimestamp()
.setFooter(`Espero que algum dia ele(a) volte`)
.setColor('BLACK')
const SCHANNEL = member.guild.channels.cache.find(channel => channel.id === `${schannel}`) 
if(SCHANNEL) { 
SCHANNEL.send(embed)
}
})


client.on("guildMemberAdd", async (member) => { 

  let guild = await client.guilds.cache.get("632377223411925015");
  let channel = await client.channels.cache.get("638046829031981066");
  if (guild != member.guild) {
    return console.log("Sem boas-vindas pra você!.");
   } else {
      let embed = await new Discord.MessageEmbed()
      .setColor("#7c2ae8")
      .setAuthor(member.user.tag, member.user.displayAvatarURL())
      .setTitle(`Boas-vindas`)
      .setImage("https://cdn.discordapp.com/attachments/715998928390324347/730479902800871525/tenor-1.gif")
      .setDescription(`<a:tp:725111678588420168> Olá **${member.user}**, Seja bem-vindo(a) ao servidor: **${guild.name}**!
💫 Atualmente estamos com: **${member.guild.memberCount} membros**, Divirta-se conosco! ❤️`)
      .setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
      .setFooter("")
      .setTimestamp();

    channel.send(embed);
  }
});


client.on("ready", () => {
  let activities = [
      `📌Utilize ${config.prefix}help para obter ajuda😊`,
      `${client.guilds.cache.size} servidores💕`,
      `🌟NUNCA DESISTA DE SEUS SONHOS !!!🌟`,
      `${client.users.cache.size} usuários💕`,
      `Meu Criador: BioonsYT#4834 💕`,
      `Me adicione use: m.invite💖`
    ],
    i = 0;
  setInterval( () => client.user.setActivity(`${activities[i++ % activities.length]}`, {
        type: "WATCHING"
      }), 12000); 
  client.user
      .setStatus("online")
      .catch(console.error);
console.log(`Estou Online!`)
console.log(`Estou conectada como: ${client.user.username}`)
console.log(`Estou conectada com: ${client.users.cache.size} usuarios, ${client.channels.cache.size} Canais e ${client.guilds.cache.size} Servidores`)
});
 

 client.on("message", async message => {
 if(message.content.startsWith('<@734819851889016902') || message.content.startsWith('<@!734819851889016902')) {
 let embed = new Discord.MessageEmbed()
    .setAuthor(`Mellone` , `https://cdn.discordapp.com/attachments/741379232516800564/747172773230542950/Disk.gif`)
 .setColor('Color')
 .setTitle('')
.setDescription(`**Olá ${message.member.user}, Meu nome é Mellone e tenho 16 anos de idade. Sou uma simples Bot criada pelo BioonsYT, Minhas funções são: Administração, Moderação, Interação, Ajuda, Diversão, Entretenimento, entre outras coisas. Meu prefixo nesse Servidor é:** \`${config.prefix}\`, **digite:** \`${config.prefix}help\` **para obter ajuda.**`)
.addField("🔗Links Importantes:", `💎**[Me adicione](https://discordapp.com/oauth2/authorize?client_id=734819851889016902&scope=bot&permissions=4656329)**\n💎**[Vote em mim](https://botsparadiscord.com/bots/734819851889016902)**\n💎**[Servidor de Suporte](https://discord.gg/PrsAtP3)**`)
.setFooter(`© Mellone • Todos os direitos reservados.` , `https://cdn.discordapp.com/attachments/707636623545860106/715053829200019466/PicsArt_05-27-01.06.05.png`)
 
 message.channel.send(embed);
 } 
});


client.login(process.env.TOKEN); //Ligando o Bot caso ele consiga acessar o token